suma2=0
for i in range(300,5001,1):
    suma = i
    suma2 = suma + suma2
print(suma2)