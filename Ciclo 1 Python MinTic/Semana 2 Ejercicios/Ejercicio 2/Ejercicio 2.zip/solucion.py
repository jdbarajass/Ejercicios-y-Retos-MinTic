entero = int(input("Digite un numero de 2 digitos "))
separacion1 = entero //10
separacion2 = entero % 10
print(separacion1)
print(separacion2)