celsius = int(input("Digite la temperatura en grados celsius"))
fahrenheit = (celsius*1.8)+ 32 
print("La temperatura en grados fahrenheot es: ",fahrenheit)
