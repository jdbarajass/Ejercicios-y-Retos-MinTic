metros = int(input("Digite un numero para convertir de metros a centimetros, pies y pulgadas "))
centimetro = metros*100
pies = metros*3.28084
pulgadas = metros*39.3701
print(centimetro," centimetro")
print(pies," pies")
print(pulgadas," pulgadas")
