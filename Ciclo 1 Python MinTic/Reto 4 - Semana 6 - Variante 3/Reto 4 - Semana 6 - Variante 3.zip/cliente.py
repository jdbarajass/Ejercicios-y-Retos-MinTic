#NO MODIFICAR, NI AGREGAR CÓDIGO EN ESTE ARCHIVO
class cliente:
  def __init__(self, nombre, edad, dinero_cuenta_bancaria, fila_interes, transaccion, cantidad_retirar, cantidad_consignar):
    self.nombre = nombre
    self.edad = edad
    self.dinero_cuenta_bancaria = dinero_cuenta_bancaria
    self.fila_interes = fila_interes
    self.transaccion = transaccion
    self.cantidad_retirar = cantidad_retirar
    self.cantidad_consignar = cantidad_consignar