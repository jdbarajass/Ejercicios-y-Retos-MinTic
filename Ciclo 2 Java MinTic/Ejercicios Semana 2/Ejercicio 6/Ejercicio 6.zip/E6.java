class E6{
    public static String join(char [] vector){
        int x;
        return String.valueOf(vector);
    }
}